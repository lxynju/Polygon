function [qx0, qy0] = friction(qx0, qy0, dt)
tau = 0.;
F = -tau*qx0/(1 + 2*dt*tau);
F(qx0 >= 0 & F < -qx0/dt) = -qx0(qx0 >= 0 & F < -qx0/dt)/dt;
F(qx0 <= 0 & F > -qx0/dt) = -qx0(qx0 >= 0 & F < -qx0/dt)/dt;
qx0 = qx0 + dt*F;
%%
F = -tau*qy0/(1 + 2*dt*tau);
F(qy0 >= 0 & F < -qy0/dt) = -qy0(qy0 >= 0 & F < -qy0/dt)/dt;
F(qy0 <= 0 & F > -qy0/dt) = -qy0(qy0 >= 0 & F < -qy0/dt)/dt;
qy0 = qy0 + dt*F;
end

