function phi = minmod(r)
phi = max(0, min(r,1));
end

