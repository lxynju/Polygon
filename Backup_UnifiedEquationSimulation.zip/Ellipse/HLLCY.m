function [g1, g2, g3] = HLLCY(etaU,etaD,qxU,qxD,qyU,qyD,zb_plus_half_y,uU,uD,vU,vD,hU,hD,g)
    v_star = 0.5*(vU + vD) + sqrt(g*hU) - sqrt(g*hD);
    h_star = 1/g*(0.5*(sqrt(g*hU) + sqrt(g*hD)) + 0.25*(vU - vD)).^2;

    SU = 0*qyU;
    SD = SU;
    SU(hU == 0) = vD(hU == 0) - 2*sqrt(g*hD(hU == 0));
    SU(hU > 0) = min(vU(hU > 0) - sqrt(g*hU(hU > 0)), v_star(hU > 0) - sqrt(g*h_star(hU > 0)));
    SD(hD == 0) = vU(hD == 0) + 2*sqrt(g*hU(hD == 0));
    SD(hD > 0) = max(vD(hD > 0) + sqrt(g*hD(hD > 0)), v_star(hD > 0) + sqrt(g*h_star(hD > 0)));
    SM = (SU.*hD.*(vD - SD) - SD.*hU.*(vU - SU))./(hD.*(vD - SD) - hU.*(vU - SU));

    g1U = qyU; 
    g1D = qyD;
    %f2L = qL.^2./hL + 0.5*g*(etaL.^2 - 2*etaL.*zb_plus_half);
    %f2R = qR.^2./hR + 0.5*g*(etaR.^2 - 2*etaR.*zb_plus_half);
    g2U = g1U.*uU;
    g2D = g1D.*uD;
    g3U = qyU.*vU + 0.5*g*(etaU.^2 - 2*etaU.*zb_plus_half_y);
    g3D = qyD.*vD + 0.5*g*(etaD.^2 - 2*etaD.*zb_plus_half_y);


    g1_star = (SD.*g1U - SU.*g1D + SU.*SD.*(etaD - etaU))./(SD - SU);
    g2_star_U = uU.*g1_star;
    g2_star_D = uD.*g1_star;
    g3_star = (SD.*g3U - SU.*g3D + SU.*SD.*(qyD - qyU))./(SD - SU);


    g1 = 0*qyU;
    g2 = 0*qyU;
    g3 = 0*qyU;

    g1(SU >= 0) = g1U(SU >= 0); g2(SU >= 0) = g2U(SU >= 0); g3(SU >= 0) = g3U(SU >= 0);

    g1(SU < 0 & SD > 0) = g1_star(SU < 0 & SD > 0); g3(SU < 0 & SD > 0) = g3_star(SU < 0 & SD > 0);
    g2(SU < 0 & SM > 0) = g2_star_U(SU < 0 & SM > 0); g2(SM <= 0 & SD > 0) = g2_star_D(SM <= 0 & SD > 0);

    g1(SD <= 0) = g1D(SD <= 0); g2(SD <= 0) = g2D(SD <= 0); g3(SD <= 0) = g3D(SD <= 0);
end

