function [f1, f2, f3] = HLLCX(etaL,etaR,qxL,qxR,qyL,qyR,zb_plus_half_x,uL,uR,vL,vR,hL,hR,g)
    u_star = 0.5*(uL + uR) + sqrt(g*hL) - sqrt(g*hR);
    h_star = 1/g*(0.5*(sqrt(g*hL) + sqrt(g*hR)) + 0.25*(uL - uR)).^2;

    SL = 0*qxL;
    SR = SL;
    SL(hL == 0) = uR(hL == 0) - 2*sqrt(g*hR(hL == 0));
    SL(hL > 0) = min(uL(hL > 0) - sqrt(g*hL(hL > 0)), u_star(hL > 0) - sqrt(g*h_star(hL > 0)));
    SR(hR == 0) = uL(hR == 0) + 2*sqrt(g*hL(hR == 0));
    SR(hR > 0) = max(uR(hR > 0) + sqrt(g*hR(hR > 0)), u_star(hR > 0) + sqrt(g*h_star(hR > 0)));
    SM = (SL.*hR.*(uR - SR) - SR.*hL.*(uL - SL))./(hR.*(uR - SR) - hL.*(uL - SL));

    f1L = qxL; 
    f1R = qxR;
    %f2L = qL.^2./hL + 0.5*g*(etaL.^2 - 2*etaL.*zb_plus_half);
    %f2R = qR.^2./hR + 0.5*g*(etaR.^2 - 2*etaR.*zb_plus_half);
    f2L = qxL.*uL + 0.5*g*(etaL.^2 - 2*etaL.*zb_plus_half_x);
    f2R = qxR.*uR + 0.5*g*(etaR.^2 - 2*etaR.*zb_plus_half_x);
    f3L = f1L.*vL;
    f3R = f1R.*vR;

    f1_star = (SR.*f1L - SL.*f1R + SL.*SR.*(etaR - etaL))./(SR - SL);
    f2_star = (SR.*f2L - SL.*f2R + SL.*SR.*(qxR - qxL))./(SR - SL);
    f3_star_L = vL.*f1_star;
    f3_star_R = vR.*f1_star;

    f1 = 0*qxL;
    f2 = 0*qxL;
    f3 = 0*qxL;

    f1(SL >= 0) = f1L(SL >= 0); f2(SL >= 0) = f2L(SL >= 0); f3(SL >= 0) = f3L(SL >= 0);

    f1(SL < 0 & SR > 0) = f1_star(SL < 0 & SR > 0); f2(SL < 0 & SR > 0) = f2_star(SL < 0 & SR > 0);
    f3(SL < 0 & SM > 0) = f3_star_L(SL < 0 & SM > 0); f3(SM <= 0 & SR > 0) = f3_star_R(SM <= 0 & SR > 0);

    f1(SR <= 0) = f1R(SR <= 0); f2(SR <= 0) = f2R(SR <= 0); f3(SR <= 0) = f3R(SR <= 0);
end

