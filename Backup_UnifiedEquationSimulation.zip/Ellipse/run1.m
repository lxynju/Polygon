%% Mesh
clc; clear all
n = 100;
x_interface = linspace(-0.1,0.1,101);
y_interface = linspace(-0.1,0.1,101);
dx = x_interface(2) - x_interface(1); dy = y_interface(2) - y_interface(1);
dt = 0.02;
x = (x_interface(1:end-1) + x_interface(2:end))/2;
y = (y_interface(1:end-1) + y_interface(2:end))/2;
[X,Y] = meshgrid(x,y);
%% Initial Condition
alpha = 4;
zb =  alpha*(X.^2 + Y.^2);
surf(zb)
eta0 = 0.02*ones(length(x),length(y));
eta0(eta0<zb) = zb(eta0<zb);
h0 = eta0 - zb;
uh0 = 0*ones(length(x),length(y));
vh0 = 0*ones(length(x),length(y));
%surf(h0)
%%
for i = 1:1000
    [uh0, vh0] = friction(uh0, vh0, dt);
end


%eta0plot = eta0;
%eta0plot(eta0== zb) = Inf;
%s = pcolor(eta0plot);
%axis equal