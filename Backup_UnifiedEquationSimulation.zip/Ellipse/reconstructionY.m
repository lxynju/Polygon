function [eta_plus_half_U_star,eta_plus_half_D_star,qx_plus_half_U_star,qx_plus_half_D_star,qy_plus_half_U_star,qy_plus_half_D_star,zb_plus_half_y,u_plus_half_U,u_plus_half_D,v_plus_half_U,v_plus_half_D,h_plus_half_U_star,h_plus_half_D_star] = reconstructionY(eta,qx,qy,zb)
    H_threshold = 1E-6/0.02;
    %% data preparation for reconstruction
    eta_minus_one = [eta(1,:); eta(1:end-1,:)];
    eta_plus_one = [eta(2:end,:); eta(end,:)];
    eta_plus_two = [eta_plus_one(2:end,:); eta_plus_one(end,:)];
    
    qx_minus_one = [0*qx(1,:); qx(1:end-1,:)];
    qx_plus_one = [qx(2:end,:); 0*qx(end,:)];
    qx_plus_two = [qx_plus_one(2:end,:); 0*qx_plus_one(end,:)];
    
    qy_minus_one = [0*qy(1,:); qy(1:end-1,:)];
    qy_plus_one = [qy(2:end,:); 0*qy(end,:)];
    qy_plus_two = [qy_plus_one(2:end,:); 0*qy_plus_one(end,:)];
    
    h = eta - zb; % depth
    h_minus_one = [0*h(1,:); h(1:end-1,:)];
    h_plus_one = [h(2:end,:); 0*h(end,:)];
    h_plus_two = [h_plus_one(2:end,:); 0*h_plus_one(end,:)];
    
    u = qx./h;
    u(h<H_threshold) = 0;
    u_plus_one = [u(2:end,:); 0*u(end,:)];
    
    v = qy./h;
    v(h<H_threshold) = 0;
    v_plus_one = [v(2:end,:); 0*v(end,:)];
    
    zb_plus_one = [zb(2:end,:); zb(end,:)];
    %% MUSCL slope limited linear reconstruction 
    % check all wet cells
    check_all_wet = h>H_threshold & h_plus_one>H_threshold & h_minus_one>H_threshold;  % only applied to wet cells away from interface 
    % reconstruction of eta (left)
    
    eta_plus_half_U = eta;      % in a dry or wet cell next to a dry cell, the face values are directly taken from centers.
    r = (eta_plus_one - eta)./(eta - eta_minus_one);
    phi = minmod(r);
    eta_plus_half_U(check_all_wet) = eta(check_all_wet) + 0.5*phi(check_all_wet).*(eta(check_all_wet) - eta_minus_one(check_all_wet));
    % eta (right)
    eta_plus_half_D = eta_plus_one;   
    r = (eta_plus_two - eta_plus_one)./(eta_plus_one - eta);
    phi = minmod(r);
    eta_plus_half_D(check_all_wet) = eta_plus_one(check_all_wet) - 0.5*phi(check_all_wet).*(eta_plus_one(check_all_wet) - eta(check_all_wet));
    
    % reconstruction of qx (left)
    qx_plus_half_U = qx;  
    r = (qx_plus_one - qx)./(qx - qx_minus_one);
    phi = minmod(r);
    qx_plus_half_U(check_all_wet) = qx(check_all_wet) + 0.5*phi(check_all_wet).*(qx(check_all_wet) - qx_minus_one(check_all_wet));
    % qx (right)
    qx_plus_half_D = qx_plus_one;
    r = (qx_plus_two - qx_plus_one)./(qx_plus_one - qx);
    phi = minmod(r);
    qx_plus_half_D(check_all_wet) = qx_plus_one(check_all_wet) - 0.5*phi(check_all_wet).*(qx_plus_one(check_all_wet) - qx(check_all_wet));
    
    % reconstruction of qy (left)
    qy_plus_half_U = qy;  
    r = (qy_plus_one - qy)./(qy - qy_minus_one);
    phi = minmod(r);
    qy_plus_half_U(check_all_wet) = qy(check_all_wet) + 0.5*phi(check_all_wet).*(qy(check_all_wet) - qy_minus_one(check_all_wet));
    % qy (right)
    qy_plus_half_D = qy_plus_one;
    r = (qy_plus_two - qy_plus_one)./(qy_plus_one - qy);
    phi = minmod(r);
    qy_plus_half_D(check_all_wet) = qy_plus_one(check_all_wet) - 0.5*phi(check_all_wet).*(qy_plus_one(check_all_wet) - qy(check_all_wet));
    
    % reconstruction of h (left)
    h_plus_half_U = h;
    r = (h_plus_one - h)./(h - h_minus_one);
    phi = minmod(r);
    h_plus_half_U(check_all_wet) = h(check_all_wet) + 0.5*phi(check_all_wet).*(h(check_all_wet) - h_minus_one(check_all_wet));
    % h (right)
    h_plus_half_D = h_plus_one;
    r = (h_plus_two - h_plus_one)./(h_plus_one - h);
    phi = minmod(r);
    h_plus_half_D(check_all_wet) = h_plus_one(check_all_wet) - 0.5*phi(check_all_wet).*(h_plus_one(check_all_wet) - h(check_all_wet));
    
    % reconstruction of bed evaluation, essential step in maintaining the
    % well-balanced property of the scheme but transforms the bed elevation
    % to a time-dependent quantity.
    
    zb_plus_half_U = zb;
    zb_plus_half_D = zb_plus_one;
    zb_plus_half_U(check_all_wet) = eta_plus_half_U(check_all_wet) - h_plus_half_U(check_all_wet);
    zb_plus_half_D(check_all_wet) = eta_plus_half_D(check_all_wet) - h_plus_half_D(check_all_wet);
    
    % reconstruction of u 
    u_plus_half_U = u;
    u_plus_half_D = u_plus_one;
    u_plus_half_U(check_all_wet) = qx_plus_half_U(check_all_wet)./h_plus_half_U(check_all_wet);
    u_plus_half_D(check_all_wet) = qx_plus_half_D(check_all_wet)./h_plus_half_D(check_all_wet);
    u_plus_half_U(h_plus_half_U<H_threshold) = 0;
    u_plus_half_D(h_plus_half_D<H_threshold) = 0;
    
    % reconstruction of v 
    v_plus_half_U = v;
    v_plus_half_D = v_plus_one;
    v_plus_half_U(check_all_wet) = qy_plus_half_U(check_all_wet)./h_plus_half_U(check_all_wet);
    v_plus_half_D(check_all_wet) = qy_plus_half_D(check_all_wet)./h_plus_half_D(check_all_wet);
    v_plus_half_U(h_plus_half_U<H_threshold) = 0;
    v_plus_half_D(h_plus_half_D<H_threshold) = 0;
    
    % bed is assumed continuous across a cell interface 
    zb_plus_half_y = max(zb_plus_half_U, zb_plus_half_D);
    
    % redefine h based on new bed, ensuring positivity of bed profile
    h_plus_half_U_star = max(0, eta_plus_half_U - zb_plus_half_y);
    h_plus_half_D_star = max(0, eta_plus_half_D - zb_plus_half_y);
    
    % redefine eta and q based on new bed
    eta_plus_half_U_star = h_plus_half_U_star + zb_plus_half_y;
    eta_plus_half_D_star = h_plus_half_D_star + zb_plus_half_y;
    
    qx_plus_half_U_star = u_plus_half_U.*h_plus_half_U_star;
    qx_plus_half_D_star = u_plus_half_D.*h_plus_half_D_star;
    
    qy_plus_half_U_star = v_plus_half_U.*h_plus_half_U_star;
    qy_plus_half_D_star = v_plus_half_D.*h_plus_half_D_star;
    
   %% A much simplified local bed modification
   deltaz = max(0, zb_plus_half_y - eta_plus_half_U);
   zb_plus_half_y = zb_plus_half_y - deltaz;
   eta_plus_half_U_star = eta_plus_half_U_star - deltaz;
   eta_plus_half_D_star = eta_plus_half_D_star - deltaz;
   deltaz = max(0, zb_plus_half_y - eta_plus_half_D);
   zb_plus_half_y = zb_plus_half_y - deltaz;
   eta_plus_half_U_star = eta_plus_half_U_star - deltaz;
   eta_plus_half_D_star = eta_plus_half_D_star - deltaz;
end

