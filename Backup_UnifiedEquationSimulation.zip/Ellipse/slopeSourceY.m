function Ss3 = slopeSourceY(zb_plus_half_y,eta_plus_half_U_star,eta_plus_half_D_star,dy,g)
    eta_minus_half_D_star = [eta_plus_half_D_star(1,:);eta_plus_half_D_star(1:end-1,:)];
    eta_bar = 0.5*(eta_minus_half_D_star + eta_plus_half_U_star);
    zb_minus_half_y = [zb_plus_half_y(1,:);zb_plus_half_y(1:end-1,:)];
    Ss3 = -g*eta_bar.*(zb_plus_half_y - zb_minus_half_y)/dy;
end

