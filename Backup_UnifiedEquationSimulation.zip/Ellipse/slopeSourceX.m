function Ss2 = slopeSourceX(zb_plus_half_x,eta_plus_half_L_star,eta_plus_half_R_star,dx,g)
    eta_minus_half_R_star = [eta_plus_half_R_star(:,1), eta_plus_half_R_star(:,1:end-1)];
    eta_bar = 0.5*(eta_minus_half_R_star + eta_plus_half_L_star);
    zb_minus_half_x = [zb_plus_half_x(:,1), zb_plus_half_x(:,1:end-1)];
    Ss2 = -g*eta_bar.*(zb_plus_half_x - zb_minus_half_x)/dx;
end

