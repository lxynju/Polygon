%% Computation Domain
clc; clear all
n = 400;
x_interface = linspace(-0.1,0.1,n+1);
y_interface = linspace(-0.1,0.1,n+1);
dx = x_interface(2) - x_interface(1); dy = y_interface(2) - y_interface(1);
dt = 0.0005;
dttrace = dt;
w = 39;
gamma = 0.14;
x = (x_interface(1:end-1) + x_interface(2:end))/2;
y = (y_interface(1:end-1) + y_interface(2:end))/2;
[X,Y] = meshgrid(x,y);
C = 0.5;

% Initial Conditions

alpha = 4;
g = 9.81;
zb =  alpha*(X.^2 + Y.^2);

eta_initial = 0.02 + 200*cos(5*atan2(Y,X)).*sqrt(X.^2 + Y.^2).^5;
eta0 = eta_initial; eta0(eta0<zb) = zb(eta0<zb);
h0 = eta0 - zb;
qx0 = 0*ones(size(eta0));
qy0 = 0*ones(size(eta0));
u0  = qx0./h0; u0(h0<1E-6) = 0;
v0 = qy0./h0; v0(h0<1E-6) = 0;
eta_hat = eta0;
qx_hat = qx0;
qy_hat = qy0;
t = 0;
ramptime = 0.2;
velocitytrace = 0;
% DIMENSIONLESS
H0 = 0.02;
R0 = sqrt(H0/alpha);
C0 = sqrt(g*H0);
T0 = R0/C0;
%%%%%%%%%%%%  Independent Variable Transform
X = X/R0; Y = Y/R0; dx = dx/R0; dy = dy/R0;
t = t/T0; dt = dt/T0;  w = w*T0;
%%%%%%%%%%%%  Dependent Varaiable Transform
eta0 = eta0/H0; eta_hat = eta_hat/H0; eta_initial = eta_initial/H0;
qx0 = qx0/(C0*H0); qx_hat = qx_hat/(C0*H0);
qy0 = qy0/(C0*H0); qy_hat = qy_hat/(C0*H0);
zb = zb/H0;
%%%%%%%%%%%% Parameter 
g = 1;
%%%%%%%%%%%% Others  %%%%%%%%%%%%%%%%%%%
H_disp = 1E-3/H0;
velocitytrace = velocitytrace/C0;
dttrace = dttrace/T0; ramptime = ramptime/T0;
%% explicit finite volume Godunov-type framework
for i = 60001:75000
    if mod(i,1000) == 0
        save(['w',num2str(i),'.mat']);
        disp(['i =',num2str(i),'||','t =',num2str(t)]);
    end
g = ( 1 + gamma*sin(w*t)*(1 - exp(-(t/ramptime)^2)));
% q is updated at the begining of each time step to account for the
% friction effect
[qx0, qy0] = friction(qx0, qy0, dt);
% Second order Runge-Kutta method 

% Intermedia Step
% 1. reconstruction
[eta_plus_half_L_star,eta_plus_half_R_star,qx_plus_half_L_star,qx_plus_half_R_star,qy_plus_half_L_star,qy_plus_half_R_star,zb_plus_half_x,u_plus_half_L,u_plus_half_R,v_plus_half_L,v_plus_half_R,h_plus_half_L_star,h_plus_half_R_star] = reconstructionX(eta0,qx0,qy0,zb);
[eta_plus_half_U_star,eta_plus_half_D_star,qx_plus_half_U_star,qx_plus_half_D_star,qy_plus_half_U_star,qy_plus_half_D_star,zb_plus_half_y,u_plus_half_U,u_plus_half_D,v_plus_half_U,v_plus_half_D,h_plus_half_U_star,h_plus_half_D_star] = reconstructionY(eta0,qx0,qy0,zb);
% 2. HLL riemann solver
[f1, f2, f3] = HLLCX(eta_plus_half_L_star,eta_plus_half_R_star,qx_plus_half_L_star,qx_plus_half_R_star,qy_plus_half_L_star,qy_plus_half_R_star,zb_plus_half_x,u_plus_half_L,u_plus_half_R,v_plus_half_L,v_plus_half_R,h_plus_half_L_star,h_plus_half_R_star,g);
[g1, g2, g3] = HLLCY(eta_plus_half_U_star,eta_plus_half_D_star,qx_plus_half_U_star,qx_plus_half_D_star,qy_plus_half_U_star,qy_plus_half_D_star,zb_plus_half_y,u_plus_half_U,u_plus_half_D,v_plus_half_U,v_plus_half_D,h_plus_half_U_star,h_plus_half_D_star,g);
% 3. source term treatment
Ss2 = slopeSourceX(zb_plus_half_x,eta_plus_half_L_star,eta_plus_half_R_star,dx,g);
Ss3 = slopeSourceY(zb_plus_half_y,eta_plus_half_U_star,eta_plus_half_D_star,dy,g);
Kq1 = - (f1(2:end-1,2:end-1)  - f1(2:end-1,1:end-2) )/dx - (g1(2:end-1,2:end-1) - g1(1:end-2,2:end-1))/dy;
Kq2 = - (f2(2:end-1,2:end-1)  - f2(2:end-1,1:end-2) )/dx - (g2(2:end-1,2:end-1) - g2(1:end-2,2:end-1))/dy + Ss2(2:end-1,2:end-1);
Kq3 = - (f3(2:end-1,2:end-1)  - f3(2:end-1,1:end-2) )/dx - (g3(2:end-1,2:end-1) - g3(1:end-2,2:end-1))/dy + Ss3(2:end-1,2:end-1);
%4. time marching
dtx = min(min(dx./(abs(u_plus_half_L) + sqrt(g*h_plus_half_L_star))));
dty = min(min(dy./(abs(v_plus_half_L) + sqrt(g*h_plus_half_L_star))));
dt = C*min(dtx, dty);
dttrace = [dttrace;dt];
maxvelocity1 = max(max(max(u_plus_half_R,v_plus_half_L)));
maxvelocity2 = max(max(max(u_plus_half_D,v_plus_half_U)));
maxvelocity = max(maxvelocity1,maxvelocity2);
velocitytrace = [velocitytrace,maxvelocity];
eta_hat(2:end-1, 2:end-1) = eta0(2:end-1, 2:end-1) + dt*Kq1;
qx_hat(2:end-1, 2:end-1) = qx0(2:end-1, 2:end-1) + dt*Kq2;
qy_hat(2:end-1, 2:end-1) = qy0(2:end-1, 2:end-1) + dt*Kq3;

% Second step
% 1. reconstruction
[eta_plus_half_L_star,eta_plus_half_R_star,qx_plus_half_L_star,qx_plus_half_R_star,qy_plus_half_L_star,qy_plus_half_R_star,zb_plus_half_x,u_plus_half_L,u_plus_half_R,v_plus_half_L,v_plus_half_R,h_plus_half_L_star,h_plus_half_R_star] = reconstructionX(eta_hat,qx_hat,qy_hat,zb);
[eta_plus_half_U_star,eta_plus_half_D_star,qx_plus_half_U_star,qx_plus_half_D_star,qy_plus_half_U_star,qy_plus_half_D_star,zb_plus_half_y,u_plus_half_U,u_plus_half_D,v_plus_half_U,v_plus_half_D,h_plus_half_U_star,h_plus_half_D_star] = reconstructionY(eta_hat,qx_hat,qy_hat,zb);
% 2. HLL riemann solver
[f1, f2, f3] = HLLCX(eta_plus_half_L_star,eta_plus_half_R_star,qx_plus_half_L_star,qx_plus_half_R_star,qy_plus_half_L_star,qy_plus_half_R_star,zb_plus_half_x,u_plus_half_L,u_plus_half_R,v_plus_half_L,v_plus_half_R,h_plus_half_L_star,h_plus_half_R_star,g);
[g1, g2, g3] = HLLCY(eta_plus_half_U_star,eta_plus_half_D_star,qx_plus_half_U_star,qx_plus_half_D_star,qy_plus_half_U_star,qy_plus_half_D_star,zb_plus_half_y,u_plus_half_U,u_plus_half_D,v_plus_half_U,v_plus_half_D,h_plus_half_U_star,h_plus_half_D_star,g);
% 3. source term treatment
Ss2 = slopeSourceX(zb_plus_half_x,eta_plus_half_L_star,eta_plus_half_R_star,dx,g);
Ss3 = slopeSourceY(zb_plus_half_y,eta_plus_half_U_star,eta_plus_half_D_star,dy,g);
Kq1_hat = - (f1(2:end-1,2:end-1)  - f1(2:end-1,1:end-2) )/dx - (g1(2:end-1,2:end-1) - g1(1:end-2,2:end-1))/dy;
Kq2_hat = - (f2(2:end-1,2:end-1)  - f2(2:end-1,1:end-2) )/dx - (g2(2:end-1,2:end-1) - g2(1:end-2,2:end-1))/dy + Ss2(2:end-1,2:end-1);
Kq3_hat = - (f3(2:end-1,2:end-1)  - f3(2:end-1,1:end-2) )/dx - (g3(2:end-1,2:end-1) - g3(1:end-2,2:end-1))/dy + Ss3(2:end-1,2:end-1);
% 4. time marching
eta0(2:end-1, 2:end-1) = eta0(2:end-1, 2:end-1) + 0.5*dt*(Kq1 + Kq1_hat);
qx0(2:end -1, 2:end-1) = qx0(2:end-1, 2:end-1) + 0.5*dt*(Kq2 + Kq2_hat);
qy0(2:end-1, 2:end-1) = qy0(2:end-1, 2:end-1) + 0.5*dt*(Kq3 + Kq3_hat);
t = t + dt;
end
%% Data Display
figure('Position', [450,300,300,300])
eta_disp_initial = eta_initial;
eta_disp_initial(eta_disp_initial - zb < H_disp) = -Inf;
s = pcolor(X,Y,eta_disp_initial);
s.FaceColor = 'interp';
shading 'flat';
colormap jet;
set(gca, 'clim', [0 2]);
axis equal;
colorbar('Ticks',[0,0.5,1,1.5 2]);

figure('Position', [750,300,300,300])
eta_disp_end = eta0;
eta_disp_end(eta_disp_end - zb < H_disp) = -Inf;
s = pcolor(X,Y,eta_disp_end);
s.FaceColor = 'interp';
shading 'flat';
colormap jet;
axis equal;
set(gca, 'clim', [0 2]);
colorbar('Ticks',[0,0.5,1,1.5 2]);

figure
plot(velocitytrace);